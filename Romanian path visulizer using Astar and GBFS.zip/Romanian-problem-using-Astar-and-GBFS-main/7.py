from queue import PriorityQueue


# Function to perform greedy best-first search
def greedy_best_first_search(graph, start, goal):
    visited = set()
    pq = PriorityQueue()
    pq.put((0, start))

    while not pq.empty():
        cost, node = pq.get()

        if node == goal:
            return True

        visited.add(node)

        for neighbor, edge_cost in graph[node]:
            if neighbor not in visited:
                pq.put((edge_cost, neighbor))

    return False


# Main program
def main():
    graph = {}

    # Get number of vertices
    num_vertices = int(input("Enter the number of vertices: "))

    # Get vertex names
    for _ in range(num_vertices):
        vertex = input("Enter vertex name: ")
        graph[vertex] = []

    # Get number of edges
    num_edges = int(input("Enter the number of edges: "))

    # Get edges and their costs
    for _ in range(num_edges):
        edge = input("Enter edge in the format 'start_vertex end_vertex cost': ")
        start_vertex, end_vertex, cost = edge.split()
        graph[start_vertex].append((end_vertex, int(cost)))

    # Get start and goal vertices
    start_vertex = input("Enter the start vertex: ")
    goal_vertex = input("Enter the goal vertex: ")

    # Perform greedy best-first search
    if greedy_best_first_search(graph, start_vertex, goal_vertex):
        print("Goal vertex is reachable from the start vertex.")
    else:
        print("Goal vertex is not reachable from the start vertex.")


if __name__ == "__main__":
    main()