# Romanian-problem-using-Astar-and-GBFS
Using A * search algorithm and GBFS search algorithm to solve the Romanian problem

Romanian problem:

The agent is on holiday in Romania and is currently located in the city of Arad. Agent has a flight from Bucharest tomorrow, so it can't be changed.
Now you need to find the shortest path to Bucharest.

![5](https://user-images.githubusercontent.com/45950266/152767984-7035cf3b-0557-4f04-a9c3-0c10e2fec763.png)


An example of running the program:

![10](https://user-images.githubusercontent.com/45950266/152768490-337b156d-35f1-4e7b-b1ce-1d544e680cb7.png)

